module Solution where

import Data.List (sortBy)
import Data.Ord  (comparing)

ranking :: [(String, Int)] -> [String]
ranking = map fst . sortBy (comparing f)
    where f (x, y) = (-y, x)

zipN :: [[a]] -> [[a]]
zipN []  = []
zipN xss
  | any null xss = []
  | otherwise    = hs : zipN ts
    where hs = map head xss
          ts = map tail xss

mapWhile :: (a -> Bool) -> (a -> a) -> [a] -> [a]
mapWhile p f = map f'
    where f' x = if p x then f' $ f x else x
