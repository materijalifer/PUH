import Data.List
import Data.Maybe
import Control.Monad
import System.Random

-- puh lekcija 15

data Tree a = Leaf a | Branch (Tree a) (Tree a) deriving (Show, Eq)

data SM s a = SM (s -> (s,a)) 

instance Monad (SM s) where
    return a = SM (\s -> (s,a))

    SM sm0 >>= fsm1 = SM $ \s0 ->
        let (s1,a1) = sm0 s0
            SM sm1 = fsm1 a1
            (s2,a2) = sm1 s1
        in (s2,a2)

get :: SM s s
get = SM (\s -> (s,s))

set :: s -> SM s ()
set s = SM $ \_ -> (s, ())

-- Vjezba 1 ---------------------------------------------

-- 1.1
nop :: SM s ()
nop = SM $ \s -> (s,())

-- nop2 :: SM s ()

instance Monad [] where
    return x = [x]
    xs >>= f = concat (map f xs)
    fail _ = []

