import Data.Char
import Prelude hiding (map, filter, foldl, foldr)
import Data.List hiding (map, filter, foldl, foldr)

takeThree :: [a] -> [a] 
takeThree = take 3

dropThree :: [a] -> [a]
dropThree = drop 3

hundredTimes :: a -> [a]
hundredTimes = replicate 100

index :: [a] -> [(a, Integer)]
index = (`zip` [1..])

-- Vjezba 2

-- 2.1

applyOnLast f xs ys = (last xs) `f` (last ys)

latestTwoPlus xs ys = applyOnLast (+) xs ys + 100


applyManyTimes f n x
    | (n <= 0)  = x
    | otherwise = f (applyManyTimes f (n-1) x) 
    

map _ []     = []
map f (x:xs) = f x : map f xs  

-- Vjezba 3

-- 3.1
listifylist :: [a] -> [[a]]
listifylist = map (:[])

cutoff :: Int -> [Int] -> [Int]
cutoff n = map (min n) 


filter :: (a -> Bool) -> [a] -> [a]
filter _ [] = []
filter p (x:xs)
  | p x         = x : filter p xs
  | otherwise   = filter p xs
  
-- VJEZBA 4

-- 4.1

sumEvenSquares xs = sum $ filter (even) $ map (^2) xs

freq x xs = length $ filter (==x) xs  

freqFilter n xs = filter (broji n xs) xs
  where broji n xs x = freq x xs >= n
    
  
-- Vjezba 5

-- 5.1

withinInterval n m xs = filter (\x -> x `elem` [n,n+1..m]) xs 

sndColumn m = filter (\x -> x == 2) $ concat $ map (zip [1..]) m







  
