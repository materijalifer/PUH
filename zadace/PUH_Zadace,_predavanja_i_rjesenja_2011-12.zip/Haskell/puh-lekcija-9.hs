-- 8.11
-- Matija Sosic
-- 0036452499

-- Vrijeme za zadacu: 7h

import Data.Char
import Data.List
import Data.Maybe

data Tricolor = Red | Green | Blue deriving Show

type Word = [Char]
type Coord = (Int, Int)

-- Vraca True za tople boje
warmColor :: Tricolor -> Bool
warmColor Red = True
warmColor _   = False

data Shape =
    Circle Double Double Double
    | Rectangle Double Double Double Double

data Point = Point Double Double deriving Show
data Shape2 = Circle2 Point Double | Rectangle2 Point Point deriving Show

-------------------------------- Vjezba 1

-- 1.1
data Date = Date Int Int Int deriving Show

showDate :: Date -> String
showDate (Date d m g) = show d ++ "." ++ show m ++ "." ++ show g ++ "." 

-- 1.2
translate :: Point -> Shape2 -> Shape2
translate (Point x y) (Circle2 (Point xs ys) r)                = Circle2 (Point (x+xs) (y+ys)) r
translate (Point x y) (Rectangle2 (Point xg yg) (Point xd yd)) = Rectangle2 (Point (xg+x) (yg+y)) (Point (xd+x) (yd+y))


-- 1.3
inShape :: Shape -> Point -> Bool
inShape (Circle x y r) (Point xp yp) = (x - xp)^2 + (y - yp)^2 <= r^2   
inShape (Rectangle x1 y1 x2 y2) (Point xp yp)
    = xp >= x1 && yp >= y1 && xp <= x2 && yp <= y2

inShapes :: [Shape] -> Point -> Bool
inShapes xs x = any (`inShape` x) xs 

-- 1.4
data Vehicle = Car String Int | Truck String Int | Motorcycle String Int | Bicycle String

totalHorsepower :: [Vehicle] -> Double
totalHorsepower = foldl zbroji 0
    where zbroji acc (Bicycle _)       = acc + 0.3
          zbroji acc (Car _ hp)        = acc + fromIntegral hp
          zbroji acc (Truck _ hp)      = acc + fromIntegral hp
          zbroji acc (Motorcycle _ hp) = acc + fromIntegral hp


data Level = Bachelor | Master | PhD deriving (Show, Eq)

data Student = Student {
    studentFirstName :: String,
    studentLastName  :: String,
    studentID        :: String,
    level            :: Level,
    avgGrade         :: Double } deriving Show


-- Vjezba 2 ---------------------------------------------------------    

showStudent :: Student -> String
showStudent s = intercalate " " [studentID s, studentFirstName s, studentLastName s]

-- 2.1
improveStudent :: Student -> Student
improveStudent stud = stud { avgGrade = min (avgGrade stud + 1.0) 5.0 } 

-- 2.2
avgGradePerLevels :: [Student] -> (Double, Double, Double)
avgGradePerLevels studs = (avg $ gradesB studs, avg $ gradesM studs, avg $ gradesP studs) 
    where gradesB = map (avgGrade) . filter ((==Bachelor) . level)  
          gradesM = map (avgGrade) . filter ((==Master) . level)
          gradesP = map (avgGrade) . filter ((==PhD) . level)
          avg xs  = sum xs / genericLength xs

-- 2.3
rankedStudents :: Level -> [Student] -> [String]
rankedStudents lvl = map studentID . sortBy compProsjek . filter ((==lvl) . level)
    where compProsjek st1 st2
            | avgGrade st1 < avgGrade st2 = GT
            | otherwise                   = LT

studenti = [Student {studentFirstName = "Martin", studentLastName = "Sosic", studentID = "123", level = Master, avgGrade = 5.0},
            Student {studentFirstName = "Matija", studentLastName = "Sosic", studentID = "335", level = PhD, avgGrade = 4.857}]      

-- 2.4
addStudent :: Student -> [Student] -> [Student]
addStudent x xs
    | studentID x `elem` map studentID xs = error "Student vec postoji!"
    | otherwise                         = x:xs

-- Vjezba 3 ------------------------------------------------------------

-- 3.1
data MyTriplet a b c = MyTriplet {
                           prvi :: a,
                           drugi :: b,
                           treci :: c } deriving Show

toTriplet :: MyTriplet a b c -> (a,b,c)
toTriplet triplet = (prvi triplet,
                     drugi triplet,
                     treci triplet)
-- 3.2
data Employee = Employee {
                    name   :: String,
                    salary :: Maybe Double } deriving Show

totalSalaries :: [Employee] -> Double
totalSalaries = foldl zbroji 0 . map salary
    where zbroji acc (Just placa) = acc + placa
          zbroji acc (Nothing)    = acc

-- 3.3
addStudent2 :: Student -> [Student] -> Maybe [Student]
addStudent2 x xs
    | studentID x `elem` map studentID xs = Nothing
    | otherwise                         = Just (x:xs)


-- DOMACA ZADACA 6 --------------------------------------------------------------    

-- 2(a)
data Weekday = Sunday | Monday | Tuesday | Wednesday | Thursday | Friday | Saturday deriving (Enum, Show, Eq)

data Month = January | February | March | April | May | June | July | August | September | October | 
             November | December deriving (Enum, Show, Eq)

weekday :: Date -> Weekday
weekday (Date day month year) = toEnum d
    where d = (day + y + y `div` 4 - y `div` 100 + y `div` 400 + (31*m) `div` 12) `mod` 7 
          a = (14 - month) `div` 12
          y = year - a
          m = month + 12*a - 2

-- 2(b)
month :: Date -> Month
month (Date _ month _) = toEnum (month - 1)

-- 2(c)
isLeapYear :: Int -> Bool
isLeapYear y
    | (y `mod` 4 == 0) && (y `mod` 100 /= 0) = True
    | y `mod` 400 == 0                       = True
    | otherwise                              = False

date :: Int -> Int -> Int -> Maybe Date
date d m y
    | y < 0                                             = Nothing
    | m == 2 && d >= 1 && d <= veljacaDani              = Just (Date d m y)
    | m `elem` [1,3,5,7,8,10,12] && d >= 1 && d <= 31   = Just (Date d m y)
    | m `elem` [4,6,9,11] && d >= 1 && d <= 30          = Just (Date d m y)
    | otherwise                                         = Nothing

    where veljacaDani = if isLeapYear y then 29 else 28 

-- 2(d)
before :: Date -> Date -> Bool
before (Date d1 m1 y1) (Date d2 m2 y2)
    | y1 < y2 = True
    | y1 > y2 = False

    | m1 < m2 = True
    | m2 < m2 = False

    | d1 < d2   = True
    | otherwise = False
    
-- 2(e)
within :: Date -> Date -> Date -> Bool
within d d1 d2 = (before d1 d) && (before d d2)

-- 3(a)
stripSuffix :: String -> String -> Maybe String
stripSuffix suf s = fmap reverse mozdaStr
    where mozdaStr = stripPrefix (reverse suf) (reverse s)

-- 3(b)
stripSuffixes :: [String] -> String -> Maybe String
stripSuffixes [] _ = Nothing
stripSuffixes (x:xs) s
    | makniSuf /= Nothing = makniSuf
    | otherwise           = stripSuffixes xs s
  where makniSuf = stripSuffix x s  

-- 4
data Author = Author {
    firstName :: String,
    lastName  :: String } deriving Show

data Publication = Book {
    title     :: String,
    authors   :: [Author], 
    publisher :: String,
    year      :: Int,
    isbn      :: String }

                | ConferencePaper {
    title      :: String,
    authors    :: [Author],
    conference :: String,
    year       :: Int,
    pages      :: (Int, Int) }

                | JournalPaper {
    title      :: String,
    authors    :: [Author],
    issn       :: String,
    year       :: Int,
    pages      :: (Int, Int) } deriving Show

izdanja = [ Book { title = "Winnetou", authors = [Author {firstName = "Karl", lastName = "May"}], publisher = "izdavac", year = 1967,
                   isbn = "3327" } ] 

-- 4(a)

-- Provjerava je li bar jedan iz prve liste u drugoj listi
-- Koristi AutoComplete sistem, npr. hof*
isInAC :: [String] -> [String] -> Bool
isInAC xs ys = or $ map check xs
    where check x
            | last x == '*' = any ((init x) `isPrefixOf`) ys
            | otherwise     = any (==x) ys


authorSearch :: String -> [Publication] -> [Publication]
authorSearch names = filter checkNames
    where checkNames pub = isInAC nameList ((map firstName $ authors pub) ++ (map lastName $ authors pub))
          nameList = words names  

-- 4(b)
titleSearch :: String -> [Publication] -> [Publication]
titleSearch naslov = filter checkTitle
    where checkTitle pub = isInAC [naslov] [title pub]

-- 4(c)
yearSearch :: (Int,Int) -> [Publication] -> [Publication]
yearSearch (y1,y2) = filter checkYear
    where checkYear pub = (year pub >= y1) && (year pub <= y2)

-- 4(d)
search :: Maybe String -> Maybe String -> Maybe (Int,Int) -> [Publication] -> [Publication]
search mAuthor mTitle mYear = authorS mAuthor . titleS mTitle . yearS mYear

    where authorS (Just names) pubs = authorSearch names pubs
          authorS Nothing pubs      = pubs

          titleS (Just title) pubs = titleSearch title pubs
          titleS Nothing pubs      = pubs

          yearS (Just year) pubs   = yearSearch year pubs
          yearS Nothing pubs       = pubs

-- 5
data Piece a = Piece a deriving (Show, Eq)

data Gameboard a = Gameboard {
    sirina :: Int,
    visina :: Int,     
    figure :: [[Maybe (Piece a)]] } deriving (Show, Eq)

type Square = (Int,Int)
type Move   = (Square,Square)

-- 5(a)
gameboard :: (Int,Int) -> Gameboard a
gameboard (x,y) = Gameboard {
                    sirina = x,
                    visina = y, 
                    figure = [] }

-- 5(b)
boardSize :: Gameboard a -> (Int,Int)
boardSize gb = (visina gb, sirina gb)

-- 5(c)
getPiece :: Square -> Gameboard a -> Maybe (Piece a)
getPiece (x,y) gb
    | x > sirina gb || y > visina gb || x < 0 || y < 0 = Nothing -- Ako polje ne postoji
    | otherwise                                        = (figure gb) !! y !! x

-- 5(d)
removePiece :: Square -> Gameboard a -> Gameboard a
removePiece (x,y) gb
    | x > sirina gb || y > visina gb || x < 0 || y < 0 = gb -- Ako polje ne postoji
    | otherwise                                        = gb { figure = retciIznad ++ [nizLijevo ++ [Nothing] ++ nizDesno] ++ retciIspod }
    where (retciIznad, red:retciIspod) = splitAt y (figure gb)
          (nizLijevo, _:nizDesno)     = splitAt x red

-- 5(e)
putPiece :: (Eq a) => Piece a -> Square -> Gameboard a -> Maybe (Gameboard a)
putPiece fig (x,y) gb
    | x > sirina gb || y > visina gb || x < 0 || y < 0 = Nothing -- Ako polje ne postoji
    | getPiece (x,y) gb /= Nothing                     = Nothing -- Ako je zauzeta
    | otherwise                                        = Just gb { figure = retciIznad ++ [nizLijevo ++ [Just fig] ++ nizDesno] ++ retciIspod }
    where (retciIznad, red:retciIspod) = splitAt y (figure gb)
          (nizLijevo, _:nizDesno)     = splitAt x red

-- 5(f)
movePiece :: (Eq a) => Move -> Gameboard a -> Maybe (Gameboard a)
movePiece (sq1@(x1,y1), sq2@(x2,y2)) gb
    | x1 > sirina gb || y1 > visina gb || x1 < 0 || y1 < 0 = Nothing -- Ako je pocetno polje izvan ploce
    | fig == Nothing                                       = Nothing -- Ako je pocetno polje prazno
    | otherwise                                            = putPiece (fromJust fig) sq2 $ removePiece sq1 gb
    where fig = getPiece (x1,y1) gb

-- 6
type ChessPiece = (Char,Char) -- Tip, boja
        
type Chessboard = Gameboard ChessPiece

initChessboard :: Chessboard
initChessboard = Gameboard {
        sirina = 8,
        visina = 8,

        figure = [ 
                    [Just (Piece('t','b')), Just (Piece('s','b')), Just (Piece('l','b')), Just (Piece('q','b')),
                     Just (Piece('k','b')), Just (Piece('l','b')), Just (Piece('s','b')), Just (Piece('t','b'))]
                 ]        
                 ++ [replicate 8 (Just (Piece ('p','b')))] 

                 ++ (replicate 4 $ replicate 8 Nothing)
                 
                 ++ [replicate 8 (Just (Piece ('p','c')))] ++
                 [
                    [Just (Piece('t','c')), Just (Piece('s','c')), Just (Piece('l','c')), Just (Piece('q','c')),
                     Just (Piece('k','c')), Just (Piece('l','c')), Just (Piece('s','c')), Just (Piece('t', 'c'))]
                 ] }

-- 6(b)
chessMove :: Move -> Chessboard -> Maybe Chessboard
chessMove (sq@(x,y), sq'@(x',y')) gb
    | figura == Nothing     = Nothing   -- Ako je pocetna pozicija prazna

    | tip == 'p' =  if ( (x == x') && (y' - y)*smjer == 1 ) ||									-- Pomak naprijed za jedan
					   ( (x == x') && (y' - y)*smjer == 2 && (y == 1 || y == 6) ) ||			-- Pomak za dva na pocetku
					   ( abs(x' - x) == 1 && enemy && (y' - y)*smjer == 1 )	                    -- Jede neprijatelja
					   then 
					       if (tip == 'b' && y' == 7) ||
							  (tip == 'c' && y' == 0)
							  then putPiece (Piece('q',tip)) sq' $ removePiece sq' $ removePiece sq gb
						   else pomakni  
					else Nothing

    | tip == 's' = if ( abs(x' - x) == 1 && (y' - y)*smjer == 2) ||							-- Vertikalni L
					  ( abs(x' - x) == 2 && (y' - y)*smjer == 1)						    -- Horizontalni L
					  then pomakni  
		           else Nothing

    | tip == 'l' = if ( abs(x' - x) == abs(y' - y) )										-- Pomak dijagonalno
				      then pomakni 
	               else Nothing
    
    | tip == 'q' = if ( abs(x' - x) == abs(y' - y) ) ||										-- Pomak dijagonalno
					   ( x == x' ) ||														-- Pomak samo po y
					   ( y == y')															-- Pomak samo po x
					   then pomakni
					else Nothing
                
    | tip == 'k' = if ( abs(x' - x) == 1 && abs(y' - y) == 1 ) ||							-- Pomak dijagonalno za jedan
					  ( sort ([abs(x' - x), abs(y' - y)]) == [0, 1] )						-- Pomak ravno za 1
					  then pomakni 
				   else Nothing

    | tip == 't' = if (x == x') ||                                                          -- Pomak samo po x
                      (y == y')                                                             -- Pomak samo po y
                      then pomakni
                   else Nothing   

    | otherwise = Nothing

    where figura  = getPiece sq gb -- Dohvati figuru s pocetnog polja
          (Just (Piece (tip,boja))) = figura        

          figura' = getPiece sq' gb -- Dohvati figuru s ciljnog polja
          (Just (Piece (tip',boja'))) = figura'

          pomakni = movePiece (sq,sq') $ removePiece sq' gb

          smjer = if boja == 'b' then 1 else (-1) -- Smjer kretanja, gore ili dolje
          enemy = tip /= tip'                     -- Je li neprijatelj na ciljom polju


-- 7
data LimitedList a = LimitedList {
        lista :: [a], 
        maxL  :: Int } deriving Show

-- 7(a)        
limitedList :: Int -> LimitedList a
limitedList n = LimitedList { lista = [], maxL = n }

-- 7(b)
first :: LimitedList a -> Maybe a
first l
    | null $ lista l = Nothing
    | otherwise      = Just (head $ lista l)

-- 7(c)
rest :: LimitedList a -> LimitedList a
rest l
    | null $ lista l = error "list empty"
    | otherwise      = l { lista = tail $ lista l }

-- 7(d)
cons :: a -> LimitedList a -> LimitedList a
cons x l
    | (length $ lista l) >= maxL l = error "list full"
    | otherwise                    = l { lista = x : (lista l) }

-- 7(e)
fromList :: [a] -> LimitedList a
fromList xs = LimitedList { lista = xs, maxL = length xs }

-- 7(f)
toList :: LimitedList a -> [a]
toList l = lista l 


-- 8
data Queue a = Queue ([a],[a]) deriving (Eq, Show)

-- 8(a)
empty :: Queue a
empty = Queue ([],[])

-- 8(b)
isEmpty :: Queue a -> Bool
isEmpty (Queue (f,r)) = null f && null r

-- 8(c)
back :: Queue a -> Queue a
back (Queue (f,r))
    | length f == 1 = Queue (reverse r, [])
    | otherwise     = Queue (tail f, r)

-- 8(d)
front :: Queue a -> Maybe a
front (Queue ([],_))   = Nothing
front (Queue (f:fs,r)) = Just f

-- 8(e)
enqueue :: a -> Queue a -> Queue a
enqueue x (Queue (f, r)) = Queue (f, x:r)

-- 8(f)
dequeue :: Queue a -> Maybe (a, Queue a)
dequeue q@(Queue (f, r))
    | isEmpty q = Nothing
    | otherwise = Just (head f, Queue (tail f,r))
