
import Data.Char
import Data.List

func a b = (min a b) + 5

condDec x = if x > 0 then x - 1 else x

foo x  = (if even x then x*2 else 2) + 1
foo' x = if even x then x*2 else 2 + 1

bigNumber x = if x >= 1000 then True else False 
bigNumber' x = x >= 1000

merge s1 s2 = 
  s1 ++ " " ++ (if (s1 < "m") then "ni" else "") ++ "je " ++ s2

merge' s1 s2 | s1 < "m"   = s1 ++ " je " ++ "s2"
		     | otherwise  = s1 ++ " nije " ++ s2
		     
grade score | score < 50 = 1
			| score < 63 = 2
			| score < 76 = 3
			| score < 89 = 4
			| otherwise  = 5
-- pazi na redoslijed, vrati prvi koji prode!			


showSalary amount bonus
  | bonus /= 0 = "Placa je  " ++ show amount ++ ", a bonus " ++ show bonus
  | otherwise  = "Placa je "  ++ show amount
  
showSalary' amount bonus 
  | amount < 0 = "Placa je negativna"
  | otherwise = "placa je " ++ show amount ++ (if bonus /= 0 then " a bonus " ++ show bonus ++ " sto je ukupno " ++ show (amount + bonus) else "")
  
concat3 a b c = a ++ (if (length b < 2) then "" else b) ++ c

pretvori broj
  | (broj == 1) = "jedan"
  | (broj == 2) = "dva" 
  | (broj == 3) = "tri"
  | (broj == 4) = "cetiri"
  | (broj == 5) = "pet"
  | (broj == 6) = "sest" 
  | (broj == 7) = "sedam" 
  | (broj == 8) = "osam" 
  | (broj == 9) = "devet"
  | (broj == 0) = "nula"   
  | otherwise   = "nepoznata znamenka!"

brojURijec broj
  | (broj < 10) = pretvori broj
  | otherwise   = brojURijec (div broj 10) ++ " " ++ pretvori (mod broj 10)
  
-- liste   

listify x = x:[]

-- Je li palindrom [1,2,3

isPalindrome s = s == reverse s   

replicate' n x = take n $ repeat x

blanks = repeat ' '
padTo10 s = s ++ take (10 - length s) blanks

-- 2.1
bez3Vanjska lista = reverse (drop 3 (reverse (drop 3 lista)))

-- 2.2
initials ime prezime = ([ime !! 0]) ++ ". " ++ ([prezime !! 0]) ++ "."

-- 2.3
prvoDulji s1 s2 = if (length s1) > (length s2) then s1 ++ s2
				  else s2 ++ s1

-- 2.4
padToN s n x 
  | (n > length s) = s ++ take (n - length s) (repeat x)
  | otherwise      = take n s
 
  
-- 2.5
kopiraj s n = if n > 1 then s ++ (kopiraj s (n - 1))
              else s
              
makeStr s1 s2 = (kopiraj s1 3) ++ (reverse s2) ++ concat(repeat (tail s1))

-- 2.6
safeHead l = if (length l == 0) then []
             else [head l]
             
-- 2.7
mkMatrix m n = replicate m (replicate n 0)

-- 2.8
imaDuplih l = if (length $ nub l) < (length l) then True
		      else False

-- 2.9
pangram s = if (length $ nub s) == 26 && ((sort s !! 0) == 'a') then True
            else False
            
-- /////////////////////////////////////////
-- Domaca zadaca 1
-- /////////////////////////////////////////

-- 2
applyAt f i xs = if i > (length xs) then xs
				 else (take i xs) ++ (f (xs !! i)):[] ++ (drop (i + 1) xs)

-- 3
rotl i list = take (length list) $ drop (if i > 0 then i else (length list) + i) (cycle list)
				 
-- 4
ubaci el i l = (take (i `mod` (length l)) l) ++ el:[] ++ (drop ((i `mod` (length l)) + 1) l)

-- 5
ubaci2D el i j l = (take j l) ++ (ubaci el i (l !! j)):[] ++ (drop (j + 1) l)

-- 6
sortUnique l = sort (nub (l))

eqLists xss yss i j = sortUnique(xss !! i) == sortUnique(yss !! j)
					  
eqLists' xss yss i j f = f (xss !! i) == f (yss !! j)
					  
-- 7
ploca = [ "TSLQKLST", 
          "PPPPPPPP", 
          "........", 
          "........", 
          "........", 
          "........", 
          "pppppppp", 
          "tslkqlst" ]

izvanPloce x y = (x < 0 || x > 7 || y < 0 || y > 7)
				 
zauzeto x y x' y' ploca = (ploca !! y' !! x' /= '.') && ( isUpper(ploca !! y !! x) == isUpper(ploca !! y' !! x') )

smjer x y ploca = if isUpper(ploca !! y !! x) then 1
				  else -1

enemy x y x' y' ploca = (ploca !! y' !! x' /= '.') && not (zauzeto x y x' y' ploca)
  
pomakniFiguru x y x' y' ploca = ubaci2D (ploca !! y !! x) x' y' (ubaci2D '.' x y ploca)
  		  					  
pomakni x y x' y' ploca
  | (izvanPloce x' y' || izvanPloce x y || zauzeto x y x' y' ploca || ploca !! y !! x == '.') = ["Opcenita greska"]
  
  | (toUpper (ploca !! y !! x) == 'P') = if ( (x == x') && (y' - y)*(smjer x y ploca) == 1 ) ||									-- Pomak naprijed za jedan
											( (x == x') && (y' - y)*(smjer x y ploca) == 2 && (y == 1 || y == 6) ) ||			-- Pomak za dva na pocetku
										    ( abs(x' - x) == 1 && enemy x y x' y' ploca && (y' - y)*(smjer x y ploca) == 1 )	-- Jede neprijatelja
										    then 
												if ((ploca !! y !! x) == 'P' && (y' == 7)) ||
												   ((ploca !! y !! x) == 'p' && (y' == 0))
												   then ubaci2D (if isUpper $ ploca !! y !! x then 'Q' else 'q') x' y' (ubaci2D '.' x y ploca)
												else pomakniFiguru x y x' y' ploca   
										 else ["Pjesak se ne smije tako micati!"]
										 
  | (toUpper (ploca !! y !! x) == 'S') = if ( abs(x' - x) == 1 && (y' - y)*(smjer x y ploca) == 2) ||							-- Vertikalni L
											( abs(x' - x) == 2 && (y' - y)*(smjer x y ploca) == 1)								-- Horizontalni L
											then pomakniFiguru x y x' y' ploca
										 else ["Konj se ne moze tako micati!"]
  
  | (toUpper (ploca !! y !! x) == 'L') = if ( abs(x' - x) == abs(y' - y) )														-- Pomak dijagonalno
											then pomakniFiguru x y x' y' ploca 
										 else ["Lovac se ne smije tako micati"]
  
  | (toUpper (ploca !! y !! x) == 'Q') = if ( abs(x' - x) == abs(y' - y) ) ||													-- Pomak dijagonalno
											( x == x' ) ||																		-- Pomak samo po y
											( y == y')																			-- Pomak samo po x
											then pomakniFiguru x y x' y' ploca
										 else ["Kraljica se ne smije tako micati"]
										 
  | (toUpper (ploca !! y !! x) == 'K') = if ( abs(x' - x) == 1 && abs(y' - y) == 1 ) ||											-- Pomak dijagonalno za jedan
											( sort ([abs(x' - x), abs(y' - y)]) == [0, 1] )										-- Pomak ravno za 1
											then pomakniFiguru x y x' y' ploca
										else ["Kralj se ne moze tako micati!"]	
  										   
  | otherwise = ["Nepostojeca figura"]
  
-- 8
median xs = if odd (length xs) then	realToFrac $ sort(xs) !! (length xs `div` 2)
			else (sort(xs) !! (length xs `div` 2) + sort(xs) !! (length xs `div` 2 + 1)) / 2
-- 9
palindrome' xs
  | (length xs == 0 || length xs == 1) = True
  | otherwise = (head xs == last xs) && palindrome' (tail $ init $ xs)
  
