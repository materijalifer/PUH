import Data.List
import Data.Char


data Sex = Male | Female deriving (Show, Read, Eq, Ord)

data Person = Person {
    idNumber :: String,
    forename :: String,
    surname  :: String,
    sex      :: Sex,
    age      :: Int,
    partner  :: Maybe Person,
    children :: [Person] } deriving (Read, Eq, Ord)

partnersForename :: Person -> Maybe String
partnersForename = fmap forename . partner

pairsChildren :: Person -> [Person]
pairsChildren p = nub $ children p ++ maybe [] children (partner p) -- ne radi!

-- Vjezba 1 ------------------------------------------------------

pero  = Person2 "Pero"  "Perić" Male   ana      marko    45 Nothing      [marko]
ana   = Person2 "Ana"   "Anić"  Female Unknown2 Unknown2 43 (Just pero)  [marko,iva]
marko = Person2 "Marko" "Perić" Male   Unknown2 Unknown2 22 (Just maja)  []
maja  = Person2 "Maja"  "Majić" Female Unknown2 Unknown2 20 (Just marko) []
iva   = Person2 "Iva"   "Ivić"  Female Unknown2 Unknown2 16 Nothing      []

-- 1.1
data Person2 = Unknown2 | Person2 {
    forename2 :: String,
    surname2  :: String,
    sex2      :: Sex,
    mother2   :: Person2,
    father2   :: Person2,
    age2      :: Int,
    partner2  :: Maybe Person2,
    children2 :: [Person2] } deriving (Show, Read, Ord)

partnersMother :: Person2 -> Maybe Person2
partnersMother = fmap mother2 . partner2

-- 1.2
parentCheck :: Person2 -> Bool
parentCheck p =  elem p (children2 m) && elem p (children2 f)
    where (m, f) = (mother2 p, father2 p)

-- 1.3
sister :: Person2 -> [Person2]
sister p = sestre -- if null sestre then Nothing else Just (sestre)
    where djeca  = (children2 $ mother2 p) ++ (children2 $ father2 p)
          sestre = filter (\x -> sex2 x == Female && x /= p) (nub djeca)

instance Eq Person2 where
    p1 == p2 = forename2 p1 == forename2 p2 && surname2 p1 == surname2 p2


-- 1.4
descendant :: Person2 -> [Person2]
descendant Unknown2 = []
descendant p = children2 p ++ concatMap descendant (children2 p)
    
data MyList a = Empty | Cons a (MyList a) deriving (Show, Read, Ord)

-- Vjezba 2 ------------------------------------------------------

-- 2.1
listHead :: MyList a -> Maybe a
listHead (Cons a _) = Just a
listHead _          = Nothing

-- 2.2
listMap :: (a -> b) -> MyList a -> MyList b
listMap _ Empty = Empty
listMap f (Cons a ost) = (f a) `Cons` (listMap f ost)


data Tree a = Null | Node a (Tree a) (Tree a) deriving (Show)

sumTree :: Tree Int -> Int
sumTree Null = 0          
sumTree (Node x left right) = x + sumTree left + sumTree right


-- Vjezba 3 --------------------------------------------------------------

-- 3.1
treeMax :: Ord a => Tree a -> a
treeMax Null = error "Prazno stablo!"
treeMax (Node x Null Null)  = x
treeMax (Node x left Null)  = maximum [x, treeMax left]
treeMax (Node x Null right) = maximum [x, treeMax right] 
treeMax (Node x left right) = maximum [x, treeMax left, treeMax right]

-- 3.2
treeElems :: Ord a => Tree a -> [a]
treeElems Null = []
treeElems (Node x left right) = (treeElems left) ++ [x] ++ (treeElems right)

-- 3.3
levelCut :: Int -> Tree a -> Tree a
levelCut (-1) _   = Null
levelCut n Null   = Null
levelCut n (Node x left right) = Node x (levelCut (n-1) left) (levelCut (n-1) right)


treeInsert :: Ord a => a -> Tree a -> Tree a
treeInsert x Null = Node x Null Null
treeInsert x t@(Node y l r) 
    | x < y     = Node y (treeInsert x l) r
    | x > y     = Node y l (treeInsert x r)
    | otherwise = t

-- Vjezba 4 ---------------------------------------------------------------

-- 4.1
listToTree :: Ord a => [a] -> Tree a
listToTree = foldr (\x acc -> treeInsert x acc) Null

-- 4.2
treeToList :: Ord a => Tree a -> [a]
treeToList = treeElems

-- 4.3
sortAndNub :: Ord a => [a] -> [a]
sortAndNub = treeToList . listToTree


data Weekday =
    Monday | Tuesday | Wednesday | Thursday | Friday | Saturday | Sunday
    deriving (Show, Enum)


-- Vjezba 5 ---------------------------------------------------------------

-- 5.1
instance Eq Weekday where
    Monday    == Monday    = True
    Tuesday   == Tuesday   = True
    Wednesday == Wednesday = True
    Thursday  == Thursday  = True
    Saturday  == Saturday  = True
    Sunday    == Sunday    = True
    _         == _         = False

-- 5.2
instance Show Person where
    show p = (forename p) ++ " " ++ unwords (map forename (children p))


-- Vjezba 6 ---------------------------------------------------------------

-- 6.1
instance (Eq a) => Eq (MyList a) where
    (Cons x _) == (Cons y _) = x == y
    _          == _          = False

-- 6.2
instance (Ord a) => Eq (Tree a) where
    t1 == t2 = sort (nub (treeToList t1)) == sort (nub (treeToList t2))

