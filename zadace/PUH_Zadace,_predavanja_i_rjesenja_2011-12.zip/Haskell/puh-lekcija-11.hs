import Data.Char
import Data.Functor
import Data.Foldable
import Prelude hiding (foldr, foldl, foldr1)
import qualified Data.Set as S
import qualified Data.Map as M
import qualified Data.Tree as T
import Data.List hiding (foldr, foldl, foldr1, maximum, concatMap, elem)
import Maybe

data Sex = Male | Female deriving (Show, Read, Eq, Ord)





data Tree a = Null | Node a (Tree a) (Tree a)




-- Vlastiti razred -------------------------

data Person = Person {
    idNumber :: String,
    forename :: String,
    surname  :: String,
    sex      :: Sex,
    age      :: Int,
    partner  :: Maybe Person,
    children :: [Person] } deriving (Read, Eq, Ord)

class Ageing a where
    currentAge :: a -> Int
    maxAge     :: a -> Int
    makeOlder  :: a -> a

instance Ageing Person where
    currentAge  = age
    makeOlder p = p {age = age p + 1}
    maxAge    _ = 123

data Breed = Beagle | Husky | Pekingese deriving (Eq, Show, Ord, Read)
data Dog = Dog {
    dogName  :: String,
    dogBreed :: Breed,
    dogAge   :: Int } deriving (Eq, Ord, Show, Read)

instance Ageing Dog where
    currentAge  = dogAge
    makeOlder d = d {dogAge = dogAge d + 1}
    maxAge d    = case dogBreed d of
        Husky -> 29
        _     -> 20


data MyList a = Empty | Cons a (MyList a) deriving (Show,Read,Eq,Ord)

-- Vjezba 1 -----------------------------------------------

-- 1.1
compareRelativeAge :: (Ageing a, Ageing b) => a -> b -> Ordering
compareRelativeAge a b = compare (relAge a) (relAge b)
    where relAge x = (fromIntegral $ currentAge x) / (fromIntegral $ maxAge x)

-- 1.2
class Nameable a where
    name :: a -> String

instance Nameable Person where
    name p = forename p ++ " " ++ surname p

instance Nameable Dog where
    name d = dogName d ++ " the Dog"

-------------------------------------------------------------

class Pushable t where
    push    :: a -> t a -> t a
    peek    :: t a -> a
    pop     :: t a -> t a

instance Pushable [] where
    push x xs   = x:xs
    peek (x:_)  = x
    peek []     = error "Empty list"
    pop (_:xs)  = xs


instance Pushable MyList where
    push x xs           = x `Cons` xs
    peek (x `Cons` _)   = x
    peek Empty          = error "Empty MyList"
    pop (_ `Cons` xs)   = xs

instance Pushable Tree where
    push x t            = Node x t Null
    pop (Node _ t _)    = t
    peek (Node x _ _)   = x
    peek Null           = error "Empty tree"

-- Vjezba 2 ---------------------------------------------------

-- 2.1
class Takeable t where
    takeSome :: Int -> t a -> t a

instance Takeable [] where
    takeSome n = take n

instance Takeable Tree where
    takeSome 0 t = t
    takeSome n t = takeSome (n-1) (pop t)

-- 2.2
class Headed t where
    headOf  :: t a -> a
    headOff :: t a -> t a


instance Headed [] where
    headOf []     = error "Empty list"
    headOf (x:_)  = x

    headOff []      = error "Empty list"
    headOff (_:xs)  = xs

instance Headed Tree where
    headOf Null         = error "Empty tree"
    headOf (Node a _ _) = a

    headOff Null        = error "Empty tree"
    headOff t           = pop t

instance Headed Maybe where
    headOf Nothing  = error "Nothing"
    headOf (Just a) = a

    headOff _       = Nothing

-- FUNCTOR -------------------------------------------------

treeMap :: (a -> b) -> Tree a -> Tree b
treeMap _ Null          = Null
treeMap f (Node x l r)  = Node (f x) (treeMap f l) (treeMap f r)

-- class Functor f where
   -- fmap :: (a -> b) -> f a -> f b

instance Functor Tree where
    fmap _ Null         = Null
    fmap f (Node x l r) = Node (f x) (fmap f l) (fmap f r)

-- Vjezba 3 -----------------------------------------------

-- 3.1
mapOnTreeMaybe :: (a -> b) -> Tree (Maybe a) -> Tree (Maybe b)
mapOnTreeMaybe = fmap . fmap

-- 3.2
data RoseTree a = RoseEmpty | RoseTree a [RoseTree a]

instance Functor RoseTree where
    fmap _ RoseEmpty        = RoseEmpty
    fmap f (RoseTree a xs)  = RoseTree (f a) (map (fmap f) xs)


-- FOLDABLE ---------------------------------------------------

instance Foldable Tree where
    foldr f z Null          = z
    foldr f z (Node x l r)  = f x (foldr f (foldr f z r) l)

toList :: Foldable t => t a -> [a]
toList = foldr (:) []

-- Vjezba 4 ----------------------------------------------------

-- 4.1
sumPositive :: (Foldable t, Num a, Ord a) => t a -> a
sumPositive = foldr (\x acc -> if x > 0 then x + acc else acc) 0

-- 4.2
size :: Foldable t => t a -> Int
size = foldr (\_ acc -> acc + 1) 0

-- 4.3
eqElems :: (Foldable t, Eq a) => t a -> Bool
eqElems =  (>=1) . length . foldr (:) [] -- jos nub ali mi javlja error

-- 4.4
-- instance Foldable RoseTree where
    
-- Vjezba 5 ----------------------------------------------------

-- 5.1
toSet :: (Foldable t, Ord a) => t a -> S.Set a
toSet = foldr (\x acc -> S.insert x acc) S.empty

-- 5.2
indexWords :: String -> M.Map String [Int]
indexWords str = foldr (\(x, idx) acc -> M.insertWith (++) x [idx] acc) M.empty (zip (words str) [0..])

------ Domaca zadaca 7 -----------------------------------------

-- 3(a)(b)

class Truthy a where
    true :: a -> Bool
    ifThenElse :: a -> b -> b -> b

    ifThenElse a b c = if true a then b else c

instance Truthy Int where
    true = (/=0)

instance Truthy [a] where
    true = not . null

instance Truthy Bool where
    true a = a

instance Truthy Char where
    true = (/='\0')

-- 3(c)
assert :: (Truthy a) => a -> b -> b
assert x y = if true x then y else error "greska"

-- 3(d)
(&&&) :: (Truthy a, Truthy b) => a -> b -> Bool
a &&& b = true a && true b

(|||):: (Truthy a, Truthy b) => a -> b -> Bool
a ||| b = true a || true b


-- 4

-- 4(a)
t = Node 'A' (Node 'B' Null Null) (Node 'C' (Node 'D' Null Null) Null)

depth :: Tree a -> Int
depth Null = 0
depth (Node a left right) = 1 + max (depth left) (depth right)

-- 4(b)
findDeepest :: (a -> Bool) -> Tree a -> Maybe a 
findDeepest p drvo = fmap (\(x,dub) -> x) (trazi p 0 drvo)

trazi :: (a -> Bool) -> Int -> Tree a -> Maybe (a, Int)
trazi _ _ Null = Nothing
trazi p d (Node a left right) = usporedi (Just (a,d)) (usporedi ld rd)
    where ld = trazi p (d + 1) left
          rd = trazi p (d + 1) right

          usporedi Nothing Nothing    = Nothing
          usporedi Nothing rightD@(Just (ar,dr)) = if p ar then rightD else Nothing
          usporedi leftD@(Just (al,dl)) Nothing  = if p al then leftD else Nothing
          usporedi leftD@(Just (al, dl)) rightD@(Just (ar, dr)) = if dr > dl then rightD else leftD 

-- 4(c)
subtrees :: (a -> Bool) -> Tree a -> [Tree a]
subtrees _ Null = []
subtrees p t@(Node a left right) = (if p a then [t] else []) ++ subtrees p left ++ subtrees p right

-- 4(d)
leaves :: Tree a -> [a]
leaves Null = []
leaves (Node a Null Null) = [a]
leaves (Node a left right) = leaves left ++ leaves right 

-- 4(e)
level :: Int -> Tree a -> [a]
level lvl = trci lvl 0
    where trci lvl curr Null = []
          trci lvl curr (Node a left right) = (if lvl == curr then [a] else []) ++ trci lvl (curr + 1) left ++
                                              trci lvl (curr + 1) right

-- 4(f)
label2 :: Tree a -> Tree (Int, a)
label2 = oznaci 0
    where oznaci el Null = Null
          oznaci el (Node a left right) = Node (el + brojEl left, a) (oznaci el left) (oznaci (el + 1 + brojEl left) right)

          brojEl Null = 0
          brojEl (Node a left right) = 1 + brojEl left + brojEl right

-- 5(a)
e = Add (Var "x") (Var "y")
e1 = Mul (Val 2.0) (Add (Var "y") (Sub (Val 3.0) (Var "x")))

data Expr = Add Expr Expr | Sub Expr Expr | Mul Expr Expr | Div Expr Expr | Val Double | Var String
showExpr :: Expr -> String
showExpr (Add x y) = showExpr x ++ "+" ++ showExpr y
showExpr (Mul x y) = safeMul x ++ "*" ++ safeMul y
showExpr (Div x y) = safeDiv x ++ "/" ++ safeDiv y
showExpr (Sub x y) = showExpr x ++ "-" ++ safeDiv y

showExpr (Val x)   = show x
showExpr (Var x)   = x

safeMul :: Expr -> String
safeMul x@(Add _ _) = "(" ++ showExpr x ++ ")" 
safeMul x@(Sub _ _) = "(" ++ showExpr x ++ ")"
safeMul x           = showExpr x

safeDiv:: Expr -> String
safeDiv x@(Add _ _) = "(" ++ showExpr x ++ ")" 
safeDiv x@(Sub _ _) = "(" ++ showExpr x ++ ")"
safeDiv x           = showExpr x

safeSub:: Expr -> String
safeSub x@(Add _ _) = "(" ++ showExpr x ++ ")" 
safeSub x@(Sub _ _) = "(" ++ showExpr x ++ ")"
safeSub x           = showExpr x

-- 5(b)
subst :: String -> Expr -> Expr -> Expr
subst imeVar zam (Add x y) = Add (subst imeVar zam x) (subst imeVar zam y)
subst imeVar zam (Sub x y) = Sub (subst imeVar zam x) (subst imeVar zam y)
subst imeVar zam (Mul x y) = Mul (subst imeVar zam x) (subst imeVar zam y)
subst imeVar zam (Div x y) = Div (subst imeVar zam x) (subst imeVar zam y)

subst imeVar zam v@(Var ime) = if imeVar == ime then zam else v
subst imeVar zam v@(Val _)   = v

-- 5(c)
type VarAssignment = M.Map String Double

eval :: VarAssignment -> Expr -> Maybe Double
eval va (Add x y) = add (eval va x) (eval va y)
eval va (Sub x y) = sub (eval va x) (eval va y)
eval va (Mul x y) = mul (eval va x) (eval va y)
eval va (Div x y) = dijeli (eval va x) (eval va y)
eval _ (Val x) = Just x
eval va (Var x) = M.lookup x va

add (Just a) (Just b) = Just (a + b)
add _ _               = Nothing
          
sub (Just a) (Just b) = Just (a - b)
sub  _ _              = Nothing

mul (Just a) (Just b) = Just (a * b)
mul  _ _              = Nothing

dijeli (Just a) (Just b) = if b == 0 then error "division by zero" else Just (a / b)
dijeli  _ _              = Nothing




