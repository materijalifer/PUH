-- 10.11.2011
-- Matija Sosic
-- 0036452499

import Data.Char
import Data.List

sum' :: Num a => [a] -> a
sum' []     = 0
sum' (x:xs) = x + sum' xs

incList :: Num a => [a] -> [a]
incList []      = []
incList (x:xs)  = x + 1 : incList xs

concat' :: [[a]] -> [a]
concat' []          = []
concat' (xs:xss)    = xs ++ concat' xss

-- Vjezba 1 --------------------------------------------

-- 1.1
product' :: Num a => [a] -> a
product' []     = 1
product' (x:xs) = x * product xs

-- 1.2
headsOf :: [[a]] -> [a]
headsOf []          = []
headsOf ([]:xss)    = headsOf xss           -- Preskoci prazne liste
headsOf (xs:xss)    = head xs : headsOf xss 

-- Vjezba 2---------------------------------------------

mnozi :: Integral a => a -> a -> [a] -> [a]
mnozi _ _ []        = []
mnozi n m (x:xs)    = x * n `mod` m : mnozi n m xs

addPredecessor :: Num a => [a] -> [a]
addPredecessor xs = add 0 xs    
    where add _ []      = []
          add n (x:xs)  = n + x : add x xs 
          

-- Vjezba 3 ----------------------------------------------

-- 3.1
equalTriplets :: Eq a => [(a,a,a)] -> [(a,a,a)]
equalTriplets [] = []
equalTriplets ((x,y,z):xs) | (x == y && y == z) = (x,y,z) : equalTriplets xs
                           | otherwise = equalTriplets xs

-- 3.2
replicate' :: Int -> a -> [a]
replicate' 0 _ = []
replicate' n x = x : replicate' (n - 1) x 


-- Vjezba 4 ----------------------------------------------

-- 4.1
drop' :: Int -> [a] -> [a]
drop' 0 xs       = xs
drop' n (x:xs)   = drop' (n - 1) xs

dropNeg n xs 
    | (n >= 0)  = drop' n xs
    | otherwise = reverse $ drop' (-1*n) (reverse xs)

-- 4.2
takeFromTo :: Int -> Int -> [a] -> [a]
takeFromTo a b xs = pom a b 0 xs
    where pom _ _ _ [] = []
          pom a b n (x:xs)
            | (n > b)              = []
            | not (n < a || n > b) = x : pom a b (n + 1) xs
            | otherwise            = pom a b (n + 1) xs

-- Vjezba 5 ------------------------------------------------

-- 5.1
eachThird :: [a] -> [a]
eachThird xs = svakiTreci 1 xs
    where svakiTreci _ [] = []   
          svakiTreci n (x:xs)
            | (n `mod` 3 == 0) = x : svakiTreci (n + 1) xs
            | otherwise        = svakiTreci (n + 1) xs

-- 5.2
crossZip :: [a] -> [a] -> [(a,a)]
crossZip (x1:x2:xs) (y1:y2:ys) = [(x1, y2), (y1, x2)] ++ crossZip xs ys
crossZip _ _                   = []

-- Vjezba 6 ------------------------------------------------

-- 6.1
length' :: [a] -> Int
length' xs = len xs 0
    where len [] n = n
          len (x:xs) n = len xs (n+1)

-- 6.2
maxUnzip :: [(Int, Int)] -> (Int, Int)
maxUnzip [] = error "Lista ne smije biti prazna!"
maxUnzip zs = najveci zs (fst (zs !! 0)) (snd (zs !! 0))
    where najveci [] a b = (a, b) 
          najveci (z:zs) a b = najveci zs (max (fst z) a) (max (snd z) b)

maxUnzip2 :: [(Int, Int)] -> (Int, Int)
maxUnzip2 []     = error "Lista ne smije biti prazna!"    
maxUnzip2 [a]    = (fst a, snd a)
maxUnzip2 (z:zs) = (max (fst z) (fst vrati), max (snd z) (snd vrati))
    where vrati = maxUnzip2 zs

-- DOMACA ZADACA 4 ----------------------------------------

-- 2
sumEven :: Num a => [a] -> a
sumEven xs = suma xs 0
    where suma (x:y:xs) n = suma xs (n+y)
          suma _ n        = n   

sumEven2 :: Num a => [a] -> a
sumEven2 xs = suma xs 0
    where suma [] _     = 0 
          suma (x:xs) n
           | (n == 1)   = x + suma xs 0
           | otherwise  = suma xs 1

-- 3a
(!) :: [a] -> Int -> [a]
(!) xs poz = uzmi (zip xs [0..]) poz
    where uzmi [] _ = []
          uzmi (x:xs) poz
            | (snd x == poz) = fst x : uzmi xs poz
            | otherwise      = uzmi xs poz
-- 3b
(!!!) :: [a] -> [Int] -> [a]
(!!!) _ []      = [] 
(!!!) xs (p:ps) = (xs ! p) ++ (xs !!! ps)
-- 3c
remove :: Eq a => a -> [a] -> [a]
remove _ [] = []
remove a (x:xs)
   | (x == a)  = xs
   | otherwise = x : remove a xs 
-- 3d
deleteEach :: Eq a => a -> [a] -> [a]
deleteEach _ [] = []
deleteEach a (x:xs)
    | (a == x)  = deleteEach a xs
    | otherwise = x : deleteEach a xs
-- 3e
insertAt :: Int -> a -> [a] -> [a]
insertAt poz el xs = ubaciNa poz el xs 1
    where ubaciNa _ el [] _ = [el]
          ubaciNa poz el (x:xs) idx
            | (poz == 0)   = el:x:xs 
            | (poz == idx) = x:el:xs
            | otherwise    = x : ubaciNa poz el xs (idx+1)
-- 3f
elemOf :: Eq a => a -> [a] -> Bool
elemOf _ [] = False
elemOf a (x:xs)
    | (a == x)  = True
    | otherwise = elemOf a xs
-- 3g
prefixOf :: Eq a => [a] -> [a] -> Bool
prefixOf [] _ = True
prefixOf _ [] = False
prefixOf (x:xs) (y:ys)
    | (x /= y)  = False
    | otherwise = prefixOf xs ys
-- 3h
substringOf :: Eq a => [a] -> [a] -> Bool
substringOf xs [] = False
substringOf xs ly@(y:ys) = (prefixOf xs ly) || (substringOf xs ys)

-- 4a
nubRight :: Eq a => [a] -> [a]
nubRight []     = []
nubRight (x:xs) = x : nubRight (deleteEach x xs)
-- 4b
nubLeft :: Eq a => [a] -> [a]
nubLeft []          = []
nubLeft (x:xs)
    | (x `elem` xs) = nubLeft xs
    | otherwise     = x : nubLeft xs
    
-- 5
--median :: (Integral a, Fractional b) => [a] -> b
median [] = error "Ne postoji medijan prazne liste"
median xs = sredina xs 0 (length xs)
    where sredina (x:xs) poz l
            | (odd l && poz == (div l 2))        = x
            | (even l && poz == ((div l 2) - 1)) = realToFrac (x + head xs) / 2 
            | otherwise                          = sredina xs (poz+1) l 

-- 6a
rank1223 :: Eq a => [a] -> [(a, Int)]
rank1223 xs = rankaj xs 1 (head xs)
    where rankaj [] _ _ = []
          rankaj (x:xs) rank last
            | (x == last) = (x, rank) : rankaj xs rank x
            | otherwise   = (x, rank + 1) : rankaj xs (rank + 1) x
-- 6b
rank1224 :: Eq a => [a] -> [(a, Int)]
rank1224 xs = rankaj xs 1 (head xs) 1
    where rankaj [] _ _ _ = []
          rankaj (x:xs) rank last next
            | (x == last) = (x, rank) : rankaj xs rank x (next+1)
            | otherwise   = (x, next) : rankaj xs next x (next+1) 

-- 7
guidedMerge :: [a] -> [a] -> [Int] -> [a]
guidedMerge xs ys ns = uzmi xs ys ns 0
    where uzmi _ _ [] _ = [] 
          uzmi [] [] _ _ = []
          uzmi xs ys (n:ns) tip
            | (tip == 0 && n > 0 && length xs /= 0) = take n xs ++ uzmi (drop n xs) ys ns 1
            | (tip == 1 && n > 0 && length ys /= 0) = take n ys ++ uzmi xs (drop n ys) ns 0
            
            | (tip == 0 && n == 0 && length xs /= 0) = uzmi xs ys ns 1
            | (tip == 1 && n == 0 && length ys /= 0) = uzmi xs ys ns 0

            | (tip == 0 && n < 0 && length xs /= 0) = uzmi (drop (abs(n)) xs) ys ns 1
            | (tip == 1 && n < 0 && length ys /= 0) = uzmi xs (drop (abs(n)) ys) ns 0
            
            | (tip == 0)                      = uzmi xs ys (ns) 1
            | otherwise                       = uzmi xs ys (ns) 0

-- 8a            
breakAt :: (Eq a) => a -> [a] -> ([a], [a])
breakAt delim xs = lomi delim xs 0
    where lomi _ [] _ = ([], [])
          lomi delim (x:xs) found
            | (delim == x && found == 0) = (ys1, ys2)
            | (found == 0)               = (x:ns1, ns2)
            | otherwise                  = (ns1, x:ns2)
            where (ys1, ys2) = lomi delim xs 1
                  (ns1, ns2) = lomi delim xs found

-- 8b
splitOn :: (Eq a) => a -> [a] -> [[a]]
splitOn delim xs
    | (b == []) = [a]
    | otherwise = a : splitOn delim b
    where (a, b) = breakAt delim xs

-- 9a
align :: Ord a => a -> [a] -> [a] -> ([a], [a])
align _ [] _ = ([], [])
align _ _ [] = ([], [])
align z n1@(x:xs) n2@(y:ys)
    | (x > y)   = (z:a1, y:b1)
    | (x < y)   = (x:a2, z:b2)
    | otherwise = (x:a3, y:b3)
    where (a1, b1) = align z n1 ys
          (a2, b2) = align z xs n2
          (a3, b3) = align z xs ys
-- 9b
align' :: Ord a => a -> [a] -> [a] -> ([a], [a])
align' _ [] [] = ([], [])
    
align' z [] (y:ys)  = (z:a1, y:b1)
    where (a1, b1) = align' z [] ys

align' z (x:xs) []  = (x:a1, z:b1)
    where (a1, b1) = align' z xs []

align' z n1@(x:xs) n2@(y:ys)
    | (x > y)   = (z:a1, y:b1)
    | (x < y)   = (x:a2, z:b2)
    | otherwise = (x:a3, y:b3)
    where (a1, b1) = align' z n1 ys
          (a2, b2) = align' z xs n2
          (a3, b3) = align' z xs ys

-- 10a
split3 :: [a] -> ([a], [a], [a])
split3 xs = (take third xs,
             take third $ drop third xs,
             drop (2 * third) xs)
    where third = div ((length xs) + 2) 3

merge2 :: Ord a => [a] -> [a] -> [a]
merge2 [] [] = []
merge2 xs [] = xs
merge2 [] ys = ys
merge2 xc@(x:xs) yc@(y:ys)
    | (x < y)   = x : merge2 xs yc
    | otherwise = y : merge2 xc ys 

merge3 :: Ord a => [a] -> [a] -> [a] -> [a]
merge3 xs ys zs = merge2 xs (merge2 ys zs)

mergeSort3 :: Ord a => [a] -> [a]
mergeSort3 []  = []
mergeSort3 [x] = [x]
mergeSort3 xs  = merge3 (mergeSort3 as) (mergeSort3 bs) (mergeSort3 cs)
    where (as,bs,cs) = split3 xs

