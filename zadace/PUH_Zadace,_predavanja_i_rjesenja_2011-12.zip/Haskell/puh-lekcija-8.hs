-- Matija Sosic
-- 0036452499

import Data.Char
import Prelude hiding (foldr, foldl, flip, curry)
import Data.List hiding (foldr, foldl)


-- Kompozicija -----------------------------


-- VJEZBA 1 --------------------------------

-- 1.1
sumEven :: [Integer] -> Integer
sumEven = sum . map (fst) . filter (odd . fst) . zip [0..]

-- 1.2
filterWords :: [String] -> String -> String
filterWords ws = unwords . filter (not . (`elem` ws)). words  

-- 1.3
--initials3 :: String -> (String -> Bool) -> String -> String
initials3 d p = unwords . map ((:d) . toUpper . head) . filter (p) . words


-- VJEZBA 2 --------------------------------

-- 2.1
maxDiff :: [Int] -> Int
maxDiff xc@(x:xs) =  maximum $ map (uncurry (-)) $ zip xc xs

-- 2.2
-- passingScores :: [(a,b)] -> [a]
-- passingScores xs = map (fst) $ filter (\(a,b) -> a > maks2) xs
--    where maks2 = div (maximum $ map (snd) xs) 2 



