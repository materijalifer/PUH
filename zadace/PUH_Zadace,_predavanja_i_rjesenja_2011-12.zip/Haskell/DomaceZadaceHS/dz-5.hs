-- Matija Sosic
-- 0036452499
-- 5. DZ

import Data.Char
import Data.List
import Data.Maybe
import Prelude
import Text.Printf

-- LEKCIJA 7 ---------------------------------------------------

-- Vjezba 1 --

-- 1.1
takeThree :: [a] -> [a]
takeThree = take 3

dropThree :: [a] -> [a]
dropThree = drop 3

hundredTimes :: a -> [a]
hundredTimes = replicate 100

-- 1.2
index :: [a] -> [(a, Integer)]
index = (`zip` [0..])

-- 1.3
divider :: Int -> [Char]
divider = (`replicate` '=')

-- Vjezba 2 --

-- 2.1
applyOnLast :: (a -> b -> t) -> [a] -> [b] -> t
applyOnLast f xs ys = (last xs) `f` (last ys)

lastTwoPlus100 :: [Integer] -> [Integer] -> Integer
lastTwoPlus100 xs ys = applyOnLast (+) xs ys + 100

-- 2.2
applyManyTimes :: Integer -> (a -> a) -> a -> a 
applyManyTimes n f x
    | (n <= 0)  = x
    | otherwise = f (applyManyTimes (n-1) f x)

applyTwice :: (a -> a) -> a -> a
applyTwice f = applyManyTimes 2 f 

-- Vjezba 3 --

-- 3.1
listifyList :: [a] -> [[a]]
listifyList = map (:[])

-- 3.2
cutoff :: Int -> [Int] -> [Int]
cutoff n = map (min n)

-- Vjezba 4 --

-- 4.1
sumEvenSquares :: [Integer] -> Integer
sumEvenSquares = sum . map (^2) . filter (even)

-- 4.2
freq :: Eq a => a -> [a] -> Int
freq x = length . filter (==x)

-- 4.3
freqFilter :: Eq a => Int -> [a] -> [a]
freqFilter n xs = filter (viseOdN xs) xs
    where viseOdN xs x = freq x xs >= n

-- Vjezba 5 --

-- 5.1
withinInterval :: Ord a => a -> a -> [a] -> [a]
withinInterval n m = filter (\x -> x >= n && x <= m)

-- 5.2
sndColumn :: [[a]] -> [a]
sndColumn = map (snd) . filter (\(a,b) -> a == 2) . concatMap (zip [1..])

sndColumn' :: [[a]] -> [a]
sndColumn' = map (!! 1)


-- Lekcija 8 ---------------------------------------------------------------

-- Vjezba 1 --

-- 1.1
sumEven :: [Integer] -> Integer
sumEven = sum . map (snd) . filter (even . fst) . zip [0..]

-- 1.2
filterWords :: [String] -> String -> String
filterWords ws = unwords . filter(not . (`elem` ws)) . words

-- 1.3
initials3 :: String -> (String -> Bool) -> String -> String
initials3 d p =  concatMap ((:d) . toUpper . head) . filter (p) . words

-- Vjezba 2 --

-- 2.1
maxDiff :: [Int] -> Int
maxDiff xc@(x:xs) = maximum . map (abs . uncurry (-)) $ zip xc xs

minDiff :: [Int] -> Int
minDiff xc@(x:xs) = minimum . map (abs . uncurry (-)) $ zip xc xs

maxMinDiff :: [Int] -> (Int, Int)
maxMinDiff xs = (minDiff xs, maxDiff xs)

-- 2.2
passingScores :: (Ord b1, Fractional b1) => [(b, b1)] -> [b]
passingScores xs = map (fst) $ filter ((>= polaMax) . snd) xs
    where polaMax =  (maximum $ map (snd) xs) / 2

-- Vjezba 3 --

-- 3.1
titleCased :: String -> Bool
titleCased = all (isUpper . head) . words

-- 3.2
sortPairs :: Ord b => [(a, b)] -> [(a, b)]
sortPairs = sortBy usporediPar
    where usporediPar p1 p2 = compare (snd p2) (snd p1)

-- 3.3
filename :: String -> String
filename s
    | (elem '/' s) = filename desniDio
    | otherwise    = s
    where desniDio = tail $ snd $ break (=='/') s

-- 3.4
maxElemIndices :: Ord a => [a] -> [Int]
maxElemIndices [] = error "empty list"
maxElemIndices xs = findIndices (== najveci) xs
    where najveci = maximum xs

-- Vjezba 4 --

-- 4.1
foldElem :: Eq a => a -> [a] -> Bool
foldElem n = foldr (\x acc -> x == n || acc) False

-- 4.2
foldRev :: [a] -> [a]
foldRev = foldr (\x acc -> acc ++ [x]) []

-- 4.3
nubRuns :: Eq a => [a] -> [a]
nubRuns = foldr (\x acc -> if null acc || x /= head acc then x : acc else acc) []

-- VJEZBA 5 --

-- 5.1
reverse' :: [a] -> [a]
reverse' = foldl (\acc x -> x:acc) []

-- 5.2
sumEven' :: [Integer] -> Integer
sumEven' = fst . foldl step (0, True)
    where  step (acc, idx) x = if idx then (acc + x, not idx) else (acc, not idx)

-- 5.3
maxUnzip :: [(Int, Int)] -> (Int, Int)
maxUnzip [] = error "empty list"
maxUnzip (p:ps) = foldl step (fst p, snd p) ps
    where step (acc1, acc2) (a, b) = (max acc1 a, max acc2 b) 


-- DOMACA ZADACA 5 ---------------------------------------------------------------

-- 3
maxIndex :: Ord a => [a] -> Int
maxIndex = minimum . maxElemIndices

-- 4
rle :: Eq a => [a] -> [(a,Int)]
rle = foldr step []
    where step = (\x acc -> if null acc || x /= (fst $ head acc) then (x, 1) : acc else (x, (snd $ head acc) + 1) : (tail acc))
                                                                              
-- 5
indexWords :: String -> [Int]
indexWords = map (snd) . snd . foldl step (0, []) . map (osiguraj) . words
    where step (cnt, ret) x = case (lookup x ret) of
                                Nothing  -> (cnt + 1, ret ++ [(x, cnt + 1)])
                                Just idx -> (cnt, ret ++ [(x, idx)])
          osiguraj s
            | (isAlphaNum $ last s) = map (toLower) s
            | (otherwise)           = map (toLower) $ init s

-- 6(a)
sfn :: String -> Bool
sfn s
    | any isLower s                                  = False  -- Samo velika slova
    | (length $ filter (=='.') s) > 1                = False  -- Ne vise od jedne tocke
    | (length leftPart > 8 || length rightPart > 4)  = False  -- Mora zadovoljavati 8.3

    | leftCheck leftPart == False                    = False  -- Provjera lijevog dijela

    | (null rightPart)                               = True   -- Provjera desnog dijela
    | all (isAlphaNum) $ tail rightPart              = True    

    | otherwise                                      = False
    where (leftPart, rightPart) = break (=='.') s
          (_, (_:lr))          = break (=='~') leftPart
          leftCheck leftPart 
            | all (isAlphaNum) leftPart             = True
            | '~' `notElem` leftPart                = False
            | all isDigit lr                        = True
            | otherwise                             = False 

-- 6(b)
-- Mice sve tocke osim zadnje
makniTocke :: String -> String
makniTocke = fst . foldr step ([], False)
    where step x (rijec, nasao)
            | nasao == False && x == '.' = (x:rijec, True)
            | nasao == True && x == '.'  = (rijec, True)
            | otherwise                  = (x:rijec, nasao) 

-- Mijenja specijalne znakove s underscore
zamijeniSUnd :: String -> String
zamijeniSUnd = map f
    where f znak
            | isAlphaNum znak || znak == '.' = znak
            | otherwise                      = '_'
            

-- Pretvara lfn u sfn sa zadanim brojem     
toSfn :: String -> String -> String
toSfn s nStr
     | is83L && is83R = map toUpper s
     | otherwise      = take 6 lu ++ "~" ++ nStr ++ take 4 ru 

    where  ureden = map toUpper $ zamijeniSUnd $ makniTocke $ filter (/=' ') s
    
           (lu,ru) = break (=='.') ureden
           (l,r)   = break (=='.') s

           is83L = length l < 9 && all isAlphaNum l
           is83R
            | null r    = True
            | r == "."  = True
            | otherwise = all isAlphaNum $ tail r 


lfn2sfn :: [String] -> String -> String
lfn2sfn xs s = pretvori xs s 1

pretvori :: [String] -> String -> Int -> String
pretvori xs s n
    | toSfn s nStr `elem` xs = pretvori xs s (n+1)
    | otherwise     = toSfn s nStr
    where nStr = show n 

-- 6(c)
sfnFolder :: [String] -> [String]
sfnFolder = foldl (\acc x -> acc ++ [lfn2sfn acc x]) []
          
-- 7
calc :: String -> Double
calc s = rek (words s)
    where rek [a] = toD a
          rek (opn1:opn2:opr:ost)
            | (opr == "*") = rek $ (show $ toD opn1 * toD opn2) : ost
            | (opr == "+") = rek $ (show $ toD opn1 + toD opn2) : ost
            | (opr == "-") = rek $ (show $ toD opn1 - toD opn2) : ost
            | (opr == "/") = if (opn2 == "0") then error "error"
                             else rek $ (show $ toD opn1 / toD opn2) : ost
          rek _ = error "error"                                                        
          toD a = read a :: Double          

-- 8
path2List :: String -> [String]
path2List = tail . foldr step []
    where step x [] = [x:""]
          step x acc@(ah:at)
            | (x /= '/') = (x:ah):at
            | otherwise  = "":(acc)
-- 9
scoreList :: [(String, String, String)] -> [(String, Double)] -> String
scoreList studenti = concatMap ispisiStud . rankajStud . sortirajStud . spoji studenti
     where ispisiStud (jmbg, ime, prez, bod, rank) = 
            printf "%s %s %s %.1f (%d)\n" jmbg ime prez bod rank


rank1223 :: Eq a => [a] -> [(a, Int)]
rank1223 xs = rankaj xs 1 (head xs)
    where rankaj [] _ _ = []
          rankaj (x:xs) rank last
            | (x == last) = (x, rank) : rankaj xs rank x
            | otherwise   = (x, rank + 1) : rankaj xs (rank + 1) x

rankajStud :: [(String, String, String, Double)] -> [(String, String, String, Double, Int)]
rankajStud studs = zipWith (\(jmbg, ime, prez, bod) rank -> (jmbg, ime, prez, bod, rank) ) studs rankovi 
    where rankovi            = map snd $ rank1223 $ map (score) studs
          score (_, _, _, a) = a 


spoji :: [(String, String, String)] -> [(String, Double)] -> [(String, String, String, Double)]
spoji studs bodovi = map upari studs
    where upari (jmbg, ime, prez) = case (lookup jmbg bodovi) of
                                        Nothing    -> error "Greska"
                                        Just score -> (jmbg, ime, prez, score)
          
sortirajStud :: [(String, String, String, Double)] -> [(String, String, String, Double)]
sortirajStud = sortBy usporediStud
    where usporediStud st1 st2
            | (score st1 < score st2) = GT
            | (score st1 > score st2) = LT
            | otherwise               = compare (prezime st1) (prezime st2)
          score   (_, _, _, a) = a
          prezime (_, _, a, _) = a

-- 10(a)
stemmer1 :: String -> String
stemmer1 s
    | lastVocPos == (-1)    = s
    | prefSize >= sufixSize = take lastVocPos s
    | otherwise             = s
    where lastVocPos
            | all (not . isVocal) s = (-1)  
            | otherwise             = maximum $ findIndices isVocal s 
          isVocal c = c `elem` ['a', 'e', 'i', 'o', 'u']

          sufixSize = length s - lastVocPos
          prefSize  = length s - sufixSize      

-- 10(b)
sortByLength :: [String] -> [String]
sortByLength = sortBy usporedi
    where usporedi s1 s2
            | (length s1 > length s2) = LT
            | otherwise               = GT

stemmer2 :: [String] -> String -> String
stemmer2 xs s = rek (sortByLength xs) s
   where rek [] s = s 
         rek (suf:xs) s
           | (suf `isSuffixOf` s && length suf <= (length s - length suf)) = take (length s - length suf) s
           | otherwise = rek xs s

-- 10(c)
stemmer3 :: [String] -> String -> String
stemmer3 xs s = rek (sortByLength xs) s
   where rek [] s = stemmer1 s 
         rek (suf:xs) s
           | (suf `isSuffixOf` s && length suf <= (length s - length suf)) = take (length s - length suf) s
           | otherwise = rek xs s

-- 10(d)
testStemmer :: [(String,String)] -> (String -> String) -> Double
testStemmer niz f = fst vrati / snd vrati * 100
    where step (score, lgt) (rijec, korijen)
            | f rijec == korijen = (score + 1, lgt + 1)
            | otherwise          = (score, lgt + 1)

          vrati = foldl step (0,0) niz
-- 10(e)
stemText :: (String -> String) -> (String -> Bool) -> String -> String
stemText stem p = unwords . map stem . filter p . words
