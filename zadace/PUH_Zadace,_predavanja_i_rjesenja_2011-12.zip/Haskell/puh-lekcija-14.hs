import Data.List
import Data.Char
import Control.Monad
import Data.Maybe
import System.IO
import System.Directory
import System.environment

inject :: a -> Maybe a
inject x = Just x

bind :: Maybe a -> (a -> Maybe b) -> Maybe b
bind Nothing _ = Nothing
bind (Just x) k = k x

-- Vjezba 1 -----------------------------

data Sex = Male | Female deriving (Show, Read, Eq, Ord)

data Person = Unknown | Person {
    idNumber :: String,
    forename :: String,
    surname  :: String,
    father   :: Maybe Person,
    mother   :: Maybe Person,
    sex      :: Sex,
    age      :: Int,
    partner  :: Maybe Person,
    children :: [Person] } deriving (Read, Eq, Ord)

-- 1.1
grandfathersPartnerForename :: Person -> Maybe String
grandfathersPartnerForename p = father p >>= father >>= partner >>= (return . forename)

-- 1.2
stripSuffix :: Eq a => [a] -> [a] -> Maybe [a]
stripSuffix s1 s2 = stripPrefix (reverse s1) (reverse s2) >>= return . reverse

removeAffixes :: String -> String -> String -> Maybe String
removeAffixes s1 s2 s3  = stripPrefix s1 s3 >>= stripSuffix s2


-- Vjezba 2 --------------------------------

-- 2.1
main5 :: IO ()
main5 = getArgs >>= (\xs <- case xs of                        
                            (f:_) -> (doesFileExist f



-- 2.2
grandfathersPartnerForename2 :: Person -> Maybe String
grandfathersPartnerForename2 p = do
                                    t <- father p
                                    d <- father t
                                    part <- partner d
                                    return (forename part)





