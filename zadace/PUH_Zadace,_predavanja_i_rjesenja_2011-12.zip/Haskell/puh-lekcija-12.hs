import Data.Char
import Data.List
import Control.Monad

-- IO Akcije -----------------------------------------------

-- main = putStrLn "hello, world!"

main2 = do
    putStrLn "hopa"
    putStrLn "cupa"

main3 = do
    putStrLn "Upisi svoj sretan broj"
    number <- getLine
    putStrLn $ "Tvoj sretan broj je " ++ number

askNumber :: IO String
askNumber = do
    putStrLn "Upisi svoj sretan broj"
    getLine

main5 :: IO ()
main5 = do
    number <- askNumber
    putStrLn $ "Tvoj sretan broj je " ++ number

-- Vjezba 1 -------------------------------------------------

-- 1.1
main :: IO ()
main = do
    a <- getLine
    b <- getLine
    putStrLn (reverse $ a ++ b)

-- 1.2
threeNumbers :: IO ()
threeNumbers = do
    a <- getLine
    b <- getLine
    c <- getLine
    putStrLn $ show $ (read a :: Int) + (read b :: Int) + (read c :: Int) 

-- Vjezba 2 -----------------------------------------------------

-- 2.1
treeStrings :: IO Int
treeStrings = do
    a <- getLine
    b <- getLine
    c <- getLine

    putStrLn (a ++ b ++ c)
    return (length a + length b + length c)

-- 2.2
askNumber9 :: IO Int
askNumber9 = do
    a <- getLine
    if all isDigit a then return (read a :: Int) else askNumber9

-- 2.3
askUser :: String -> (String -> Bool) -> IO String
askUser m p = do
    putStrLn m
    s <- getLine
    if p s then return s else askUser m p

askUser' :: Read a => String -> (String -> Bool) -> IO a
askUser' m p = do
    putStrLn m
    s <- getLine
    if p s then return $ read s else askUser' m p

-- 2.4
inputStrings :: IO [String]
inputStrings = do
    s <- getLine
    if s == "" then return [] 
       else do
         xs <- inputStrings
         return (s : xs)

-- Vjezba 3 ----------------------------------------------------------

-- 3.1
ucitaj :: IO [String]
ucitaj = do
    n  <- askNumber9
    xs <- replicate n getLine

    return reverse
    
