-- 3.11.2011
-- Matija Sosic
-- 0036452499

import Data.Char
import Data.List


-- Pattern Matching
magicNumber :: Int -> String
magicNumber 42 = "Yeah"
magicNumber _  = "Ne, probaj opet"

fst' :: (a,b) -> a
fst' (x, _) = x

--addVectors :: (Double, Double) -> (Double, Double) -> (Double, Double)
addVectors (x1, y1) (x2, y2) = (x1 + x2, y1 + y2) 

head' :: [a] -> a
head' []	= error "nema glave"
head' (x:_)	= x

tail' :: [a] -> [a]
tail' []	= []
tail' (_:xs) = xs

-- VJEZBA 1 --------------------------------------

-- 1.1
uzmiGlavu :: [[a]] -> a
uzmiGlavu ((x:_):_) 	= x
uzmiGlavu (_:(x:_):_) 	= x
uzmiGlavu (_:_:(x:_):_) = x
uzmiGlavu _ 			= error "joj"

-- 1.2
firstColumn :: [[a]] -> [a]
firstColumn xss = [x | (x:_) <- xss] 

-- 1.3
shoutOutLoud :: String -> String
shoutOutLoud s = unwords [(replicate 3 x) ++ y | (x:y) <- words s]

-- 1.4
baremTri :: [[[a]]] -> [[[a]]]
baremTri xsss = [xss | xss@((x:xs):(y:ys):(z:zs):_) <-  xsss]

-- VJEZBA 2 --------------------------------------

-- 2.1
pad :: String -> String -> (String, String)
pad s1@(h1:t1) s2@(h2:t2) = ( puni maxL (toUpper h1:t1),
                              puni maxL (toUpper h2:t2) )
  where maxL = max (length s1) (length s2)
        puni n s = take n (s ++ repeat ' ')

-- 2.2

median :: [Int] -> Double
median xs
  | (even $ length sxs) = realToFrac (sxs !! pola + sxs !! (pola-1)) / 2
  | otherwise = realToFrac (sxs !! pola)
  where pola = div (length xs) 2
        sxs  = sort xs
    


quartiles :: [Int] -> (Double, Double, Double)
quartiles xs
  | (length xs < 3)    = error "Prekratka lista"
  | (even $ length xs) = (median $ fst evenPair,
                          median sxs,
                          median $ snd evenPair)

  | otherwise          = (median $ fst oddPair,
                          median sxs,
                          median $ snd oddPair)
  where evenPair = splitAt pola sxs
        oddPair  = (fst evenPair, tail $ snd evenPair)
        pola     = div (length xs) 2
        sxs      = sort xs
  

-- VJEZBA 3 ----------------------------------------

-- 3.1

padLet :: String -> String -> (String, String)
padLet s1@(h1:t1) s2@(h2:t2) =
    let maxL = max (length s1) (length s2)
        puni n s = take n (s ++ repeat ' ')
        
    in ( puni maxL (toUpper h1:t1),
       puni maxL (toUpper h2:t2) )
      
-- 3.2 
quartilesLet :: [Int] -> (Double, Double, Double)
quartilesLet xs
  | (length xs < 3)    = error "Prekratka lista"
  | (even $ length xs) = let evenPair = splitAt pola sxs
                             oddPair  = (fst evenPair, tail $ snd evenPair)
                             pola     = div (length xs) 2
                             sxs      = sort xs in 
                         (median $ fst evenPair,
                          median sxs,
                          median $ snd evenPair)

  | otherwise          = let evenPair = splitAt pola sxs
                             oddPair  = (fst evenPair, tail $ snd evenPair)
                             pola     = div (length xs) 2
                             sxs      = sort xs in 
                         (median $ fst oddPair,
                          median sxs,
                          median $ snd oddPair)

-- VJEZBA 4 ---------------------------------------

brojiJedinice (a,b) = 
    case (a,b) of
    (1,1) -> "nalaze dvije"
    (1,_) -> "nalazi jedna"
    (_,1) -> "nalazi jedna"
    (_,_) -> "ne nalazi niti jedna" 

opisiListu (_,_) [] = error "lista je prazna!"
opisiListu (a, b) xs = 
    "U paru se [ " ++ brojiJedinice (a, b) ++ " ] jedinica" 
    ++ " i drugi element liste je <" ++ show (xs !! 1) ++ ">]"
    


-- Domaca zadaca 3 ---------------------------------

-- 2
dropThree :: Eq a => [a] -> (a,a,a) -> [a]
dropThree xs@(x:y:z:_) (a,b,c)
  | (x == a && y == b && z == c) = drop 3 xs
  | otherwise = xs
  
dropThree xs@(x:y:_) (a,b,_)
   | (x == a && y == b) = drop 2 xs
   | otherwise = xs


dropThree xs@(x:_) (a,_,_)
   | (x == a) = drop 1 xs
   | otherwise = xs

dropThree [] (a,b,c) = error "prazna lista!"

-- 3
pairs :: [a] -> [(a,a)]
pairs [] = []
pairs xs = [(xs !! b, xs !! a) | a <- [0..length xs - 1], b <- [0..a - 1]]

-- 4a
counts :: Ord a => [a] -> [(a, Int)]
counts xs = [(ls !! 0, length ls) | ls <- group $ sort xs]
-- 4b
group' :: Eq a => [a] -> [[a]]
group' xs = nub [ filter (==x) xs  | x <- xs]
-- 4c
counts' :: Eq a => [a] -> [(a, Int)]
counts' xs = [(ls !! 0, length ls) | ls <- group' xs]

-- 5
showScore :: Double -> String
showScore x 
    | abs x `elem` [2,3,4]                                               = show x ++ " boda"
    | (drop (length (show x) - 2) (show x)) `elem` [".2", ".3", ".4"]    = show x ++ " boda"
    | abs x == 1                                                         = show x ++ " bod"
    | otherwise                                                          = show x ++ " bodova"

-- 6a
insert' :: Eq a => a -> t -> [(a, t)] -> [(a, t)]
insert' k v xs = (k, v):[(a, b) | (a, b) <- xs, a /= k]
-- 6b
delete' :: Eq t => t -> [(t, t1)] -> [(t, t1)]
delete' k xs = [(a,b) | (a,b) <- xs, a /= k]
-- 6c
get k xs
  | (dobri == [])   = error "non-existing key"     
  | otherwise       = snd $ head $ dobri   
  where dobri = filter (\(a,_) -> a == k) xs

get' xs k
  | (dobri == [])   = k     
  | otherwise       = snd $ head $ dobri   
  where dobri = filter (\(a,_) -> a == k) xs

-- 7
rastavi :: String -> [String]
rastavi s
 | (not $ isAlphaNum $ last s) = [init s, last s:[]]
 | otherwise             = [s]

chunk :: String -> [String]
chunk s = concat [rastavi rijec | rijec <- words s]

unchunk :: [String] -> String
unchunk ss = tail $ concatMap (\s -> if isAlphaNum $ head s then ' ':s else s) ss

-- 8
translate :: [(String, String)] -> String -> String
translate dict s = unchunk $ map (get' dict) (chunk s)

-- 9a
fromSeed :: Integer -> Integer
fromSeed seed = mod (a * seed + c) m
    where a = 1664525
          c = 1013904224
          m = 2^32
-- 9b
randoms :: Integer -> [Integer]
randoms seed = iterate fromSeed seed

-- 10a
choose :: Integer -> [a] -> (Integer, a)
choose seed xs = (rnd, xs !! (fromIntegral $ rnd))
    where rnd = mod (fromSeed seed) (fromIntegral $ length xs)

-- 10b
podniz :: Int -> Int -> [a] -> [a]
podniz a b xs = take (b - a + 1) (drop a xs) 

zamijeni :: Int -> Int -> [a] -> [a]
zamijeni a b xs 
  | ( a /= b) =   podniz 0 (idx1 - 1) xs ++
                  [xs !! idx2] ++
                  podniz (idx1 + 1) (idx2 - 1) xs ++
                  [xs !! idx1] ++
                  podniz (idx2 + 1) (length xs - 1) xs
  | otherwise =   xs                
    where idx1 = min a b
          idx2 = max a b    

randZamijeni (seed, xs) = (noviSeed,
                        zamijeni a b xs)
    where rands    = take 2 (iterate fromSeed seed)
          noviSeed = toInteger $ mod (fromIntegral $ rands !! 1) (length xs)
          a        = mod (fromIntegral $ rands !! 0) (length xs)
          b        = mod (fromIntegral $ rands !! 1) (length xs)
          

shuffle :: Integer -> [a] -> (Integer, [a])
shuffle seed xs = last $ take (length xs) $ iterate randZamijeni (seed, xs)     
 
