-- 25.10.2011

-- Matija Sosic
-- 0036452499

import Data.Char
import Data.List


doubles = [x*2 | x <- [1..10]]

doublesFromTo a b = [x*2 | x <- [(min a b)..(max a b)]]

sums1 = [x + y | x <- [1..10], y <- [1..10]]

sums2 = [x + y | x <- [1..10], y <- [1..10], x < y]

sums3 = [x + y | x <- [1..10], y <- [1..10], x < y, odd x || even y]

lengths xss = [length xs | xs <- xss]

microLength xss = sum $ lengths xss

food = [s1 ++ " " ++ s2 | s1 <- ["hladna", "svjeza", "topla"], 
						  s2 <- ["torta", "gibanica", "salata"]]
						  
codes = [ [c1, c2] | c1 <- "abc", c2 <- "123"]


-- Caesar code
vrti c = if ( c == succ 'z' ) then 'a' else c
			
sukc c n 
  | (n == 0) = c 
  | otherwise =  (sukc (vrti $ (succ c)) (n - 1))
			 
caesarCode s n = [(sukc c n) | c <- s, c /= ' ']

onlyDigits s = [c | c <- s, isDigit c]

upperaj s = [toUpper(c) | c <- s]

-- Magic numbers
magicNumbers x n = [broj | broj <- [1..n], nep <- [1,3..n], broj * nep == x] 

slovaURec s = microLength [r | r <- words s, length r > 3]

isPalindrom s = upperaj (concat (words s)) == upperaj (concat (words (reverse s)))

sumMatrix m = sum [e | row <- m, e <- row]

incMatrix m = [ [e + 1 | e <- row] | row <- m ]

atLeast100 xs = and [x >= 100 | x <- xs] 

containsDigit xs = or [isDigit x | x <- xs]

-- 3.1
flipaj xs = concat [reverse el | el <- xs] 
-- 3.2
takeMins xs ys = [ el | el <- ys, el == (minimum xs)]
-- 3.3
isMatrix m = and [ length row == length (head m) | row <- m]

-- 3.4
elem x xs = or [el == x | el <- xs]

pairsUpTo100 = [(x, y) | x <- [0..100], y <- [0..100]]

pairsSumTo100 = [(x, y) | x <- [0..100], y <- [0..100], x + y == 100]

pitagora = [(a,b,c) | c <- [1..10], b <- [1..c], a <- [1..b], a^2 + b^2 == c^2]


-- 4.1
applyToPair f p = (fst p) `f` (snd p)
addPair p = applyToPair (+) p

-- 4.2
inCircle r x y n = [(a, b) | a <- [(-10),(-10)+n..10], b <- [(-10),(-10)+n..10], ((x-a)^2 + (y-b)^2) < r^2]

-- 4.3
step xs = zip xs (tail xs)

-- 5.1
indices x xs = [idx | (idx, val) <- (zip [0..] xs), val == x] 

-- 5.2
showLineNumbers s = [show idx ++ " " ++ line | (idx, line) <- (zip [1..] (lines s))]

-- 5.3
haveAlignment xs ys = or [valX == valY | (idx, valX, valY) <- (zip3 [0..] xs ys)]
common xs ys = nub [q:(take p $ drop q ys) | p <- [0..length xs], q <- [0..length ys], 
                                             (take p $ drop q xs) == (take p $ drop q ys), length (take p $ drop q ys) > 0]

-- ///////////////
-- Domaca zadaca 2
-- ///////////////

-- 2
atEach :: (t -> t1) -> [t] -> [t1]
atEach f xs = [f x | x <- xs]

-- 3(a)
odbaciZadnji :: [a] -> [a]
odbaciZadnji s = take (length s - 1) s

rastavi :: [String] -> (String, [Char], [Char], Int)
rastavi l = (l !! 0,                                                          -- ime
             odbaciZadnji $ unwords $ reverse $ drop 2 $ reverse $ drop 1 l,  -- prezime
             odbaciZadnji $ concat $ take 1 $ drop (length l - 2) l,          -- spol
             read (concat $ drop (length l - 1) l) :: Int)                    -- godinaRodenja
 
readEntries :: String -> [(String, [Char], [Char], Int)]            
readEntries s = [rastavi (words line) | line <- lines s]

-- 3(b)
--muskiStarijiOd n l :: Int -> [(String, String, String, Int)] -> [(String, String)]
muskiStarijiOd n l = [(ime, prez) | (ime, prez, spol, god) <- l, 2011 - god > n] 

-- 3(c)
razlikaManjaOD n l = [(imeM, imeZ) | (imeM, pM, sM, gM) <- l, (imeZ, pZ, sZ, gZ) <- l, 
                                     sM == "M" && sZ == "Z",
                                     abs(gM - gZ) < n]

-- 4
getElems :: [Int] -> [a] -> [a]
getElems is xs = [xs !! idx | idx <- is, idx < length xs, idx >= 0]

-- 5(a)
crossOver :: Int -> [a] -> [a] -> ([a], [a])
crossOver i xs ys = (take i xs ++ drop i ys,
                     take i ys ++ drop i xs)

-- 5(b)
mutate :: (Enum a) => Int -> [a] -> [a]
mutate i xs = take i xs ++ [succ (xs !! i)]++ drop (i + 1) xs

-- 6
interlace :: [a] -> [a] -> [a]
interlace xs ys = concat [[a, b] | (a, b) <- zip xs ys]

-- 7
vratiIdxAkoTrue :: (Num t, Enum t) => (b -> Bool) -> [b] -> [t]
vratiIdxAkoTrue f xs = [idx | (idx, val) <- zip [0..] xs, f val]

stvoriIntervale :: (Num a) => [a] -> a -> [(a, a)]
stvoriIntervale xs duljina 
  | (xs == []) = [(0, duljina - 1)]
  | otherwise  = (0, (xs !! 0) - 1) 
                 : [(a, b - 1) | (idxA, a) <- zip [0..] xs, (idxB, b) <- zip [0..] xs, idxB - idxA == 1]
                 ++ [(xs !! (length xs - 1), duljina - 1)]

podniz :: Int -> Int -> [a] -> [a]
podniz a b s = take (b - a + 1) $ drop a s

izvadiPodnizove :: [(Int, Int)] -> String -> [String]
izvadiPodnizove l s = [podniz a b s | (a, b) <- l, podniz a b s /= ""] 

decamelCase :: String -> String
decamelCase s = atEach toLower (unwords $ izvadiPodnizove (stvoriIntervale (vratiIdxAkoTrue isUpper s) (length s)) s)
                               
-- 8
wordHamming :: String -> String -> Int
wordHamming s1 s2 = sum [1 | (c1, c2) <- zip s1 s2, c1 /= c2] 
                    + abs(length s1 - length s2)

-- 9(a)
hasWord :: String -> String -> Bool
hasWord w s = or [r == w | r <- words s]                               
       
-- 9(b)
wordIndices :: String -> String -> [Int]
wordIndices w s = [idx | (idx, r) <- zip [0..] (words s), r == w]    

-- 9(c)
wordIndicesWith :: (String -> Bool) -> String -> [Int]
wordIndicesWith p s = [idx | (idx, r) <- zip [0..] (words s), p r]    
       
-- 9(d)
wordIndicesSimilarTo :: Int -> String -> String -> [Int]
wordIndicesSimilarTo n w s = [idx | (idx, r) <- zip [0..] (words s), 
                              wordHamming r w <= n]        
-- 9(e)
linesWithWordLike :: Int -> String -> String -> [(Int, Int, String)]
linesWithWordLike n w s = [(idxL, idxR, r) | (idxL, l) <- zip [0..] (lines s),
                                             (idxR, r) <- zip [0..] (words l),
                                             wordHamming r w <= n]

-- 10(a)
uMala :: String -> String
uMala s = [toLower (c) | c <- s, isAlpha c]

vigenere :: String -> String -> String
vigenere key s = [sukc ki (ord(ki) - ord('a')) | (ki, si) <- zip (take (length s) (cycle key)) (uMala s)]

-- 10(b)
spusti :: Char -> Int
spusti c = ord c - ord 'a'
 
unvigenere :: String -> String -> String 
unvigenere key s = [chr(97 +((spusti si - spusti ki) `mod` 26)) | (ki, si) <- zip (take (length s) (cycle key)) (uMala s)]
                                             
-- 10(c)
secret = "wzjdacrwarcclwqhcqklqldqkpnxppwtlq"

isItIn :: String -> [String] -> Bool
isItIn s xs = and [isInfixOf r s | r <- xs]

pogadaj :: String -> [String]
pogadaj tajna = [unvigenere [a,b,c] tajna | a <- ['a'..'z'], b <- ['a'..'z'], c <- ['a'..'z'], 
                 isItIn (unvigenere [a,b,c] tajna) ["the", "to"]]

-- Odgovor: To map fold or filter that is the question



