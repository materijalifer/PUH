import Data.Char
import Data.List


addPairs :: [(Int, Int)] -> [Int]
addPairs xs = [x + y | (x,y) <- xs]

onlyAlpha :: [Char] -> [Char]
onlyAlpha s = [ c | c <- s, isAlpha c]

-- Integer je neogranicen, a Int nije

factorial :: Integer -> Integer
factorial n = product [1..n]

circumference :: Double -> Double
circumference r = 2 * pi * r

number :: Int -> Int -> Int
number x y = x*10 + y

bez a b = a + b
-- a je tipska varijabla, cita se alfa

listifySnd :: (a, b) -> [b]
listifySnd p = [snd p]
